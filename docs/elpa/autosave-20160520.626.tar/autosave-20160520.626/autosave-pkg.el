;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "autosave" "20160520.626"
  "Save buffers automatically."
  ()
  :url "https://github.com/10sr/emacs-lisp/blob/master/autosave.el"
  :commit "e4928282f97bce43165c4de46118bc923cc1977c"
  :revdesc "e4928282f97b"
  :keywords '("utility")
  :authors '(("10sr" . ""))
  :maintainers '(("10sr" . "")))
