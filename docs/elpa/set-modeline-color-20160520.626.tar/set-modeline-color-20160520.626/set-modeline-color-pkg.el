;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "set-modeline-color" "20160520.626"
  "Set mode-line color according to writability state."
  ()
  :url "https://github.com/10sr/emacs-lisp/blob/master/set-modeline-color.el"
  :commit "e4928282f97bce43165c4de46118bc923cc1977c"
  :revdesc "e4928282f97b"
  :keywords '("utility" "modeline")
  :authors '(("10sr" . ""))
  :maintainers '(("10sr" . "")))
