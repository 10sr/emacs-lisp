;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sl" "20161217.1404"
  "An Emacs clone of sl(1)."
  '((cl-lib "0.5"))
  :url "https://github.com/xuchunyang/sl.el"
  :commit "0882117728be91276b815e18c2a66106bf9d69d3"
  :revdesc "0882117728be"
  :authors '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers '(("Chunyang Xu" . "mail@xuchunyang.me")))
