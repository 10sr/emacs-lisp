;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gosh-mode" "20230724.835"
  "Programming language gauche editing tools."
  '((emacs "28.1"))
  :url "https://github.com/mhayashi1120/Emacs-gosh-mode"
  :commit "44b81bc34d47030ca95107696b080e2dd64f8720"
  :revdesc "44b81bc34d47"
  :keywords '("lisp" "gauche" "scheme" "edit")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
