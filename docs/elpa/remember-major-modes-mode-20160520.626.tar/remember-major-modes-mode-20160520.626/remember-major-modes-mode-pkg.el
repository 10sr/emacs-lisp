;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remember-major-modes-mode" "20160520.626"
  "Remember major-modes for files."
  ()
  :url "https://github.com/10sr/emacs-lisp/blob/master/remember-major-modes-mode.el"
  :commit "e4928282f97bce43165c4de46118bc923cc1977c"
  :revdesc "e4928282f97b"
  :keywords '("major-mode")
  :authors '(("10sr" . ""))
  :maintainers '(("10sr" . "")))
