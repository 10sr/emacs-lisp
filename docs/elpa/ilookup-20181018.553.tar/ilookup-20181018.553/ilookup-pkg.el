;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ilookup" "20181018.553"
  "Incremental dictionary lookup."
  ()
  :url "https://github.com/10sr/emacs-lisp/blob/master/ilookup.el"
  :commit "c7b9617304abe6998cbc7b8a8b4dc6e7490b4612"
  :revdesc "c7b9617304ab"
  :keywords '("utility")
  :authors '(("10sr" . ""))
  :maintainers '(("10sr" . "")))
