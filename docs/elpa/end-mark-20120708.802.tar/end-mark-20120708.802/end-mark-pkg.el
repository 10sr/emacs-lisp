;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "end-mark" "20120708.802"
  "Show mark at the end of buffer."
  ()
  :url "https://github.com/tarao/elisp"
  :commit "cd08de7a240e549311d223a6ad189994a56470a7"
  :revdesc "cd08de7a240e"
  :authors '(("INA Lintaro" . "ina@kuis.kyoto-u.ac.jp"))
  :maintainers '(("INA Lintaro" . "ina@kuis.kyoto-u.ac.jp")))
