;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term-cursor" "20190514.2241"
  "Change cursor shape in terminal."
  '((emacs "26.1"))
  :url "https://github.com/h0d"
  :commit "d6c9b46c6ad73875db4ce04cac335846f86fb7e7"
  :revdesc "d6c9b46c6ad7"
  :keywords '("terminals"))
