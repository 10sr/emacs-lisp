;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-bars" "20251122.1751"
  "Highlight indentation with bars."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/jdtsmith/indent-bars"
  :commit "40bb86f47bd8cb5caa59d4c8cf64faaf5399c160"
  :revdesc "40bb86f47bd8"
  :keywords '("convenience")
  :authors '(("J.D. Smith" . "jdtsmith+elpa@gmail.com"))
  :maintainers '(("J.D. Smith" . "jdtsmith+elpa@gmail.com")))
