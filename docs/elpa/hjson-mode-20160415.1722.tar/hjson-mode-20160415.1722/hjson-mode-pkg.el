;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hjson-mode" "20160415.1722"
  "Major mode for editing Hjson files."
  '((emacs "24.3"))
  :url "https://github.com/xuchunyang/hjson-mode"
  :commit "4a8e23d28673778c75eeaf2cd08e52dae17d36cf"
  :revdesc "4a8e23d28673"
  :keywords '("json")
  :authors '(("Chunyang Xu" . "xuchunyang.me@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang.me@gmail.com")))
