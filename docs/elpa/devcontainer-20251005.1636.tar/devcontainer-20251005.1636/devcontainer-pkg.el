;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devcontainer" "20251005.1636"
  "Support for devcontainer."
  '((emacs "29.1"))
  :url "https://github.com/johannes-mueller/devcontainer.el"
  :commit "87894ae74a79b61bee93e0925b49c287846c0deb"
  :revdesc "87894ae74a79"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
