;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "terminal-title" "20160520.626"
  "Set terminal title."
  ()
  :url "https://github.com/10sr/emacs-lisp"
  :commit "e4928282f97bce43165c4de46118bc923cc1977c"
  :revdesc "e4928282f97b"
  :keywords '("terminal" "title" "console")
  :authors '(("10sr" . ""))
  :maintainers '(("10sr" . "")))
