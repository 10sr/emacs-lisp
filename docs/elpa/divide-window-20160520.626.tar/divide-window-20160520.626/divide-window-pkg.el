;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "divide-window" "20160520.626"
  "Split window evenly."
  ()
  :url "https://github.com/10sr/emacs-lisp"
  :commit "e4928282f97bce43165c4de46118bc923cc1977c"
  :revdesc "e4928282f97b"
  :keywords '("window")
  :authors '(("10sr" . ""))
  :maintainers '(("10sr" . "")))
