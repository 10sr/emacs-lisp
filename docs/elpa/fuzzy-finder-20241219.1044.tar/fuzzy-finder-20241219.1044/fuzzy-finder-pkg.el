;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fuzzy-finder" "20241219.1044"
  "Fuzzy Finder App Integration."
  '((emacs "24.4"))
  :url "https://github.com/10sr/fuzzy-finder-el"
  :commit "ed3fb35d33b38d5baad49ed5a2ea046085de4498"
  :revdesc "ed3fb35d33b3"
  :keywords '("matching")
  :authors '(("10sr" . "8.slashes@gmail.com"))
  :maintainers '(("10sr" . "8.slashes@gmail.com")))
