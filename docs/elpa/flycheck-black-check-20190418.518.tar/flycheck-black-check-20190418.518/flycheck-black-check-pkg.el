;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-black-check" "20190418.518"
  "Black check."
  '((flycheck "0.0.1")
    (emacs    "24"))
  :url "https://github.com/10sr/flycheck-black-check"
  :commit "8f3b235f53fa4918b3c3a2aba68e9ae21385754c"
  :revdesc "8f3b235f53fa"
  :keywords '("languages" "tools")
  :authors '(("10sr" . ""))
  :maintainers '(("10sr" . "")))
