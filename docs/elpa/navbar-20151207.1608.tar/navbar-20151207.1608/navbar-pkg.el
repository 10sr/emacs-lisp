;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "navbar" "20151207.1608"
  "Navigation bar for Emacs."
  '((emacs "24.4"))
  :url "https://github.com/papaeye/emacs-navbar"
  :commit "25ad7a83fa54856d12205c9a85c0b22d3bfed8ea"
  :revdesc "25ad7a83fa54"
  :keywords '("convenience")
  :authors '(("papaeye" . "papaeye@gmail.com"))
  :maintainers '(("papaeye" . "papaeye@gmail.com")))
