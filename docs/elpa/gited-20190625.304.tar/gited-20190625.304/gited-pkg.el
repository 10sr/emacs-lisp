;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gited" "20190625.304"
  "Operate on Git branches like dired."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://github.com/calancha/Gited"
  :commit "9adec7a31ae9d848171ac577d9f8d5a0ca1ed950"
  :revdesc "9adec7a31ae9"
  :keywords '("git" "vc" "convenience")
  :authors '(("Tino Calancha" . "tino.calancha@gmail.com"))
  :maintainers '(("Tino Calancha" . "tino.calancha@gmail.com")))
