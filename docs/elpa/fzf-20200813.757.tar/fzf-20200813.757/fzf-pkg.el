;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf" "20200813.757"
  "A front-end for fzf."
  '((emacs "24.4"))
  :url "https://github.com/bling/fzf.el"
  :commit "879a521b682a71e778d281d9b9480e57d123d34a"
  :revdesc "879a521b682a"
  :keywords '("fzf" "fuzzy" "search"))
