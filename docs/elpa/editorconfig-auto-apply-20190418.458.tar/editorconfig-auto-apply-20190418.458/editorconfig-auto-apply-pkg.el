;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "editorconfig-auto-apply" "20190418.458"
  "Auto apply editorconfig properties."
  '((editorconfig "0.0.1")
    (emacs        "24"))
  :url "https://github.com/10sr/editorconfig-auto-apply-el"
  :commit "0dc12735ccf6e733b1e2685b27b191c5a4e364d9"
  :revdesc "0dc12735ccf6"
  :keywords '("tools")
  :authors '(("10sr" . ""))
  :maintainers '(("10sr" . "")))
