;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sky-color-clock" "20210306.428"
  "A clock widget for modelines with real-time sky color and moonphase/weather icon."
  ()
  :url "https://github.com/zk-phi/sky-color-clock"
  :commit "525122ffb94ae4ac160de72c2ee0ade331d2e80a"
  :revdesc "525122ffb94a")
