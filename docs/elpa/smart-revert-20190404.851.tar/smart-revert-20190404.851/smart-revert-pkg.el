;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-revert" "20190404.851"
  "Revert buffers wisely."
  '((switch-buffer-functions "0.0.1"))
  :url "https://github.com/10sr/emacs-lisp"
  :commit "826565cb3c866dbd83e776ad669dbeecda9aa6cb"
  :revdesc "826565cb3c86"
  :keywords '("buffer" "revert")
  :authors '(("10sr" . ""))
  :maintainers '(("10sr" . "")))
