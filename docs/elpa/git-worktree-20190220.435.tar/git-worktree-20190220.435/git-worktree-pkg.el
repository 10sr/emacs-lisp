;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-worktree" "20190220.435"
  "Manage git worktrees."
  ()
  :url "https://github.com/10sr/git-worktree-el"
  :commit "870333c0a9b76d568690ed89fd1aa1699dedd52f"
  :revdesc "870333c0a9b7"
  :keywords '("util" "git" "vcs")
  :authors '(("10sr" . "8slashes+el[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8slashes+el[at]gmail[dot]com")))
