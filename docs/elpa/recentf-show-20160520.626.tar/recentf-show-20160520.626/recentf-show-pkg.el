;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recentf-show" "20160520.626"
  "Neat recentf view."
  '((recentf "0"))
  :url "https://github.com/10sr/emacs-lisp"
  :commit "e4928282f97bce43165c4de46118bc923cc1977c"
  :revdesc "e4928282f97b"
  :keywords '("recentf" "view" "show")
  :authors '(("10sr" . ""))
  :maintainers '(("10sr" . "")))
