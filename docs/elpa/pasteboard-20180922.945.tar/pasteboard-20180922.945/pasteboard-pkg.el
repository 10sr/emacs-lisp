;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pasteboard" "20180922.945"
  "Use osx pasteboard for yank and paste."
  ()
  :url "https://github.com/10sr/emacs-lisp/blob/master/pasteboard.el"
  :commit "619f7dec2cfd3d5189b48e4ce21183ac67b1f1c5"
  :revdesc "619f7dec2cfd"
  :keywords '("utility" "clipboard" "osx")
  :authors '(("10sr" . ""))
  :maintainers '(("10sr" . "")))
